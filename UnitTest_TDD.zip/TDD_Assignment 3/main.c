#include <stdio.h>

int main()
{

}


char WinnerChecker(char Player1, char Player2) {


	if ((Player1 == 'R' && Player2 == 'S') || (Player1 == 'P' && Player2 == 'R') || (Player1 == 'S' && Player2 == 'P')) {
		return Player1; // Player1 is Winner
	}
	else if (Player1 == Player2)
		return 'D'; // D for Draw
	else
		return Player2;  // Player2 is Winner

}