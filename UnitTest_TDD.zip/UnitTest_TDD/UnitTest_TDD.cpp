#include "pch.h"
#include "CppUnitTest.h"

extern "C" char WinnerChecker(char, char);

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace UnitTestTDD
{
	TEST_CLASS(UnitTestTDD)
	{
	public:

		TEST_METHOD(Player1_Winner)
		{

			char Player1;
			char Player2;
			char Result;

			Player1 = 'R';
			Player2 = 'S';
			Result = WinnerChecker(Player1, Player2);
			Assert::AreEqual(Player1, Result);

		}

		TEST_METHOD(Player2_Winner)
		{

			char Player1;
			char Player2;
			char Result;

			Player1 = 'S';
			Player2 = 'R';
			Result = WinnerChecker(Player1, Player2);
			Assert::AreEqual(Player1, Result);
		}

		TEST_METHOD(Draw)
		{

			char Player1;
			char Player2;
			char Result;

			Player1 = 'S';
			Player2 = 'S';
			Result = WinnerChecker(Player1, Player2);
			Assert::AreEqual('D', Result);
		}
	};
}